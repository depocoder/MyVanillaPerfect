#version 430 compatibility

#define FILTER_HERE UPSCALE_TERRAIN
#define IS_THE_END 1
#define THIS_IS_DISTANT_HORIZONS 1

#include "/main_f.glsl"
