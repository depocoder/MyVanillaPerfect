Re-covered 4.0 (Vanilla) (1.21.5+)

1. Options
    Use the mod "Respackopts" to access this resource pack's settings in-game.
    
    Alternatively, you can use your file explorer to change which files
    this resource pack should use.

   a) Disable animated textures
        Go to "/assets/carl/textures/item/" and replace the animated textures
        with the ones located in the "not_animated/" folder.
    
    b) Old animated textures
        Old versions of the animated textures for Respiration and Depth Strider
        can be found in the "/assets/carl/textures/item/alternative/" folder.
        Make sure to replace the .png.mcmeta files too.

    c) Make the background of the recipe book button transparent
        Go to "/assets/minecraft/textures/gui/sprites/recipe_book/"
        and replace the textures with the ones located in the "transparent/" folder.

    d) Use an alternative texture for Quick Charge
        Go to "/assets/carl/textures/item/" and replace 'quick_charge.png'
        with one of the textures located in the "alternative/" folder.
    
    e) Pixelated Pack Icon
        In the root directory, replace the 'pack.png' file with 'pack_32x32.png'.

2. Changelog
	Update 4.0
    - made Efficiency's pickaxe glyph more golden
    - added detail to Bane of Arthropods
    - made animations of Respiration and Curse of Vanishing less frequent
    - added shadow to Curse of Vanishing's ribbon and removed the fade from it
    - made Enchanted Book look more vanilla
    - color correction of paper in Respiration, Aqua Affinity, Bane of Arthropods, Efficiency, Mending, Silk Touch, Swift Sneak and Fire Protection
    - added one-pixel shadow to Unbreaking and Curse of Binding
    - color correction of shadow in Lure and Looting
    - increased max supported pack format to 120
    - updated pack.png
    
    Respackopts
    - fixed `Animated` and `Static` button labels appearing as `True` and `False`
    - renamed Pack Icon options from `Default` and `Pixelated` to `High Resolution` and `Pixel Art`
    - fixed and simplified config and conditions; cleaned up formatting in en_us.json
